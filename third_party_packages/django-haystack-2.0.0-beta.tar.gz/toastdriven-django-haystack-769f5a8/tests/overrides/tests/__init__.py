from overrides.tests.altered_internal_names import *
